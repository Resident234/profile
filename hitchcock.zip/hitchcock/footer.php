<div class="credits section-inner">
			
	<p>&copy; <?php echo date('Y'); ?> <a href="<?php echo esc_url( home_url() ); ?>"><?php bloginfo('name'); ?></a></p>
	<p><a href="http://www.andersnoren.se">Anders Norén</a> - <a href="http://wp-templates.ru/" title="Русские шаблоны WordPress">wp темы</a></p>
	
	<div class="clear"></div>
	
</div> <!-- /credits -->

<?php wp_footer(); ?>

</body>
</html>